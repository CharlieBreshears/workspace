package test;

import org.junit.runners.Suite.SuiteClasses;
import org.junit.runners.Suite;
import org.junit.runner.RunWith;

@RunWith(Suite.class)
@SuiteClasses({BankAccountTest.class})

public class LabTestSuite {

}
